/*********************************************
 * Copyright 2016 Absa ©
 * 29 Jun 2016
 * @author Eon van Tonder
 * @auther Nakedi Mabusela
 * @author Abigail Munzhelele
 * @author Jannie Pieterse
 * 
 * All rights reserved
 *********************************************/
package za.co.absa.pangea.ops.auth.provider;

import org.keycloak.adapters.springsecurity.authentication.KeycloakAuthenticationProvider;

/**
 * The Class PangeaAuthenticationProvider.
 */
public class PangeaAuthenticationProvider extends KeycloakAuthenticationProvider {

}
