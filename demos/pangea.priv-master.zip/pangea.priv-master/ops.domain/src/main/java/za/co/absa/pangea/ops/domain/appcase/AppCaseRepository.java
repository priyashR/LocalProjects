package za.co.absa.pangea.ops.domain.appcase;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author hannes
 * @since 09/02/2017
 *
 */
public interface AppCaseRepository extends JpaRepository<AppCase, Long> {

}
