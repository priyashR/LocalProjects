create table APPCASE (ID int8 not null, CUSTOMER_ACCOUNTNUMBER int8, CUSTOMER_NAME varchar(255), PRODUCT_ID int8, STEP_CODE varchar(255), primary key (ID))
create sequence APPCASE_SEQ
