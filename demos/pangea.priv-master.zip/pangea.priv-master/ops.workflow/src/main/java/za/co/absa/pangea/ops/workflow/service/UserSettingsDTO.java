package za.co.absa.pangea.ops.workflow.service;

public class UserSettingsDTO {

	private String defaultTab;

	public String getDefaultTab() {
		return defaultTab;
	}

	public void setDefaultTab(String defaultTab) {
		this.defaultTab = defaultTab;
	}
	
}
