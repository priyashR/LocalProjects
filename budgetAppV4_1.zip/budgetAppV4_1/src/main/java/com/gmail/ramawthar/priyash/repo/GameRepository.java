package com.gmail.ramawthar.priyash.repo;

import com.gmail.ramawthar.priyash.model.*;
import org.springframework.data.repository.CrudRepository;

public interface GameRepository extends CrudRepository<Game, Integer> {

}